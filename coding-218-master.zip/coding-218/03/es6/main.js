// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
// import Vue from 'vue'
// import Todolist from './Todolist'
// Vue.config.productionTip = false

// new Vue({
//   el:'#app',
//   components:{
//     Todolist
//   },
//   template:'<Todolist />'
// })


// let  const
// var name = 'woniu'
// {
  
//   let name = 'imooc'
// }
// let lang = 'vuejs'
// lang = 'react'
// console.log(lang)

// const name = 'woniu'
// console.log(`
//   hello ${name}！！！
//   hello world
// `)
const double = (num) => num*2

const add = (num1,num2=1)=>{
  return num1+num2
}
// function add
// function (num1, num2){
//   let num2 = num2||1
// }
// console.log(add(3,4))
// console.log(add(3))
// let arr = [5,6]
// console.log(add(...arr))
// console.log([1,2,3,...arr])


// const key = 'job'
// const obj = {
//   key,
//   num:1,
//   str:'woniu',
//   work(){

//   },
//   [key]:'fe',
//   [key+'world']:'fe'
// }
// console.log(obj)

// let arr = [1,2]
// // let num1 = arr[1]
// // let num2 = arr[2]
// let [num1,num2] = arr
// console.log(num1,num2)

// const obj = {type:'IT',name:'woniu'}
// const {type,name} = obj

import sayHi from './module1'

sayHi()
// console.log(name)







