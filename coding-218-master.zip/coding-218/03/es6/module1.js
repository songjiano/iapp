
export const name = 'woniu123'
export const job = 'fe'

export function sayHello(){
  console.log('hello world')
}

// export default function(){
//   console.log('vuejs 还不错')
// }
// export default{

// }